using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Text playerScoreText;
    public Text aiScoreText;
    public GameObject ball;
    public string scoringObjectName;

    private int playerScore = 0;
    private int aiScore = 0;
    private Ball ballController;

    void Start()
    {
        ballController = ball.GetComponent<Ball>();
        ResetBall();
    }

    void Update()
    {
        // Check for ball hitting the scoring object
        if (ball.transform.position.x > 8) // Example condition for hitting right wall
        {
            if (scoringObjectName == "right_score")
            {
                playerScore++;
                playerScoreText.text = playerScore.ToString();
            }
            else if (scoringObjectName == "left_score")
            {
                aiScore++;
                aiScoreText.text = aiScore.ToString();
            }
            ResetBall();
        }
        else if (ball.transform.position.x < -8) // Example condition for hitting left wall
        {
            if (scoringObjectName == "left_score")
            {
                aiScore++;
                aiScoreText.text = aiScore.ToString();
            }
            else if (scoringObjectName == "right_score")
            {
                playerScore++;
                playerScoreText.text = playerScore.ToString();
            }
            ResetBall();
        }
    }

    public void ResetBall()
    {
        ballController.ResetBall();
    }
}
