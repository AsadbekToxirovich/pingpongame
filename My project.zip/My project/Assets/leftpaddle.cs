using UnityEngine;

public class Paddle : MonoBehaviour
{
    public float speed = 10f;
    public KeyCode upKey;
    public KeyCode downKey;

    void Update()
    {
        Vector3 position = transform.position;

        if (Input.GetKey(upKey))
        {
            position.y += speed * Time.deltaTime;
        }
        if (Input.GetKey(downKey))
        {
            position.y -= speed * Time.deltaTime;
        }

        transform.position = position;
    }
}
